import React, { useEffect, useState } from "react";
import "./App.css";

function App() {
  const [events, setEvents] = useState([]);

  const fetchEvents = async () => {
    try {
      const res = await fetch("http://localhost:5000/events");
      const data = await res.json();
      setEvents(data);
    } catch (error) {
      console.error("Error fetching events:", error);
    }
  };

  useEffect(() => {
    fetchEvents();
    const interval = setInterval(fetchEvents, 15000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="app">
      <h1>GitHub Webhook Events</h1>
      <div className="event-list">
        {events.map((event, index) => (
          <div key={index} className="event-card">
            <div className="event-message">{event.message}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
