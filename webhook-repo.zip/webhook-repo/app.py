from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient
from datetime import datetime

app = Flask(__name__)
CORS(app)

client = MongoClient("mongodb+srv://ayushbarakoti20010:N6y2WXKvTJ5bW5Nc@cluster0.5ubsapv.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
db = client.webhookDB
events_collection = db.events

@app.route('/webhook', methods=['POST'])
def webhook():
    event_type = request.headers.get('X-GitHub-Event')
    payload = request.json

    if not payload or not event_type:
        return jsonify({'error': 'Invalid payload or missing event type'}), 400

    message = None
    timestamp = datetime.utcnow().strftime("%d %B %Y - %I:%M %p UTC")

    if event_type == "push":
        author = payload["pusher"]["name"]
        branch = payload["ref"].split("/")[-1]
        message = f'{author} pushed to {branch} on {timestamp}'

    elif event_type == "pull_request":
        action = payload["action"]
        if action in ["opened", "reopened"]:
            author = payload["pull_request"]["user"]["login"]
            from_branch = payload["pull_request"]["head"]["ref"]
            to_branch = payload["pull_request"]["base"]["ref"]
            message = f'{author} submitted a pull request from {from_branch} to {to_branch} on {timestamp}'
        elif action == "closed" and payload["pull_request"]["merged"]:
            author = payload["pull_request"]["user"]["login"]
            from_branch = payload["pull_request"]["head"]["ref"]
            to_branch = payload["pull_request"]["base"]["ref"]
            message = f'{author} merged branch {from_branch} to {to_branch} on {timestamp}'

    if message:
        events_collection.insert_one({
            "message": message,
            "timestamp": datetime.utcnow()
        })
        return jsonify({'status': 'success'}), 200
    else:
        return jsonify({'status': 'ignored', 'reason': 'Unhandled event type or action'}), 200

@app.route('/events', methods=['GET'])
def get_events():
    events = list(events_collection.find({}, {"_id": 0}))
    return jsonify(events), 200

if __name__ == '__main__':
    app.run(debug=True)
